package racetimingms.jwt;


import lombok.Data;

@Data
public class UsernameAndPasswordAuthenticationRequest {

    private String email;
    private String username;
    private String password;
    
}
