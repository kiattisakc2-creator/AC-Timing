package racetimingms.model.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Generated;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@Generated
@EqualsAndHashCode(callSuper = true)
public class LogoutResponse extends CommonResponse {

}
